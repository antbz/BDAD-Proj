-- Ao alterar Status ou Remarks de Type -> atualizar last_mod_date

DROP TRIGGER IF EXISTS gatilho2;
