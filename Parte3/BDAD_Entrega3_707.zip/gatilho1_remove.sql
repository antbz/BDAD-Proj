-- Ao inserir um novo tuplo em Request, criar e associar um documento vazio correspondente

DROP TRIGGER IF EXISTS gatilho1;
